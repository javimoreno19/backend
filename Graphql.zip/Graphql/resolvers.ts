import { Collection, ObjectId } from "mongodb";
import { Vuelo, VueloModel } from "./types.ts";
import { fromModelToVuelo } from "./utils.ts";

export const resolvers = {
    Query: {
      vuelos: async (
        _: unknown,
        args: { origen?: string; destino?: string },
        context: { VuelosCollection: Collection<VueloModel> },
      ): Promise<Vuelo[]> => {
        const query: Record<string, string> = {};
        if (args.origen) query.origen = args.origen;
        if (args.destino) query.destino = args.destino;
  
        const vuelosModel = await context.VuelosCollection.find(query).toArray();
        return vuelosModel.map((VueloModel) => fromModelToVuelo(VueloModel));
      },
  
      vuelo: async (
        _: unknown,
        { id }: { id: string },
        context: { VuelosCollection: Collection<VueloModel> },
      ): Promise<Vuelo | null> => {
        const flightModel = await context.VuelosCollection.findOne({
          _id: new ObjectId(id),
        });
        if (!flightModel) {
          return null;
        }
        return fromModelToVuelo(flightModel);
      },
    },
  
    Mutation: {
      addFlight: async (
        _: unknown,
        { origen, destino, fechaHora }: { origen: string; destino: string; fechaHora: string },
        context: { FlightsCollection: Collection<VueloModel> },
      ): Promise<Vuelo> => {
        const { insertedId } = await context.FlightsCollection.insertOne({
          origen,
          destino,
          fechayhora,
        });
  
        const flightModel = {
          _id: insertedId,
          origen,
          destino,
          fechayhora,
        };
  
        return fromModelToVuelo(flightModel);
      },
    },
  };