import { Vuelo, VueloModel } from "./types.ts";

export const fromModelToVuelo = (VueloModel: VueloModel): Vuelo=> {
  return {
    id: VueloModel._id!.toString(),
    origen: VueloModel.origen,
    destino: VueloModel.destino,
    fechayhora: VueloModel.fechayhora,
  };
};